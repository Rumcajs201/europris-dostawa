/*
  EUROPRIS DOSTAWY v49 – MODUŁ STATYSTYK PRIVACY-FIRST

  Nie zapisuje:
  - adresu IP,
  - dokładnej lokalizacji GPS,
  - numeru sklepu ani trasy,
  - imienia/nazwiska kierowcy,
  - PIN-u,
  - pełnego User-Agent.

  Wymaga arkusza Google o nazwie: Europris_Statystyki
  Arkusz jest tworzony automatycznie przy pierwszym zdarzeniu.
*/

const EUROPRIS_STATS_SHEET = "Europris_Statystyki";
const EUROPRIS_STATS_RETENTION_DAYS = 35;
const EUROPRIS_ALLOWED_EVENTS = new Set([
  "app_open", "plan_load_ok", "plan_load_error", "route_open", "excel_export",
  "gps_ok", "gps_denied", "gps_error", "offline", "online", "pwa_installed"
]);
const EUROPRIS_ALLOWED_OS = new Set(["Android", "iOS", "Windows", "macOS", "Linux", "Other"]);
const EUROPRIS_ALLOWED_DEVICE = new Set(["Phone", "Tablet", "Desktop"]);
const EUROPRIS_ALLOWED_MODE = new Set(["PWA", "Browser"]);
const EUROPRIS_ALLOWED_LANG = new Set(["pl", "no", "en", "other"]);

/*
  WAŻNE:
  W istniejącym doGet(e) dodaj na samym początku:
    const statsResponse = europrisHandleStatsGet_(e);
    if (statsResponse) return statsResponse;

  W istniejącym doPost(e) dodaj na samym początku:
    const statsResponse = europrisHandleStatsPost_(e);
    if (statsResponse) return statsResponse;

  Jeżeli nie masz doPost(e), możesz utworzyć:
    function doPost(e) {
      const statsResponse = europrisHandleStatsPost_(e);
      if (statsResponse) return statsResponse;
      return europrisJson_({ ok: false, error: "Unknown action" });
    }
*/

function europrisHandleStatsGet_(e) {
  const p = (e && e.parameter) || {};
  if (p.action !== "stats_summary") return null;
  if (!europrisValidToken_(p.token)) return europrisJson_({ ok: false, error: "Unauthorized" });
  return europrisJson_(europrisStatsSummary_());
}

function europrisHandleStatsPost_(e) {
  let body = {};
  try {
    body = JSON.parse((e && e.postData && e.postData.contents) || "{}");
  } catch (err) {
    return europrisJson_({ ok: false, error: "Invalid JSON" });
  }

  if (body.action !== "stats_event") return null;
  if (!europrisValidToken_(body.token)) return europrisJson_({ ok: false, error: "Unauthorized" });

  europrisSaveStatsEvent_(body);
  return europrisJson_({ ok: true });
}

function europrisValidToken_(token) {
  // Używa tego samego tokenu, który jest już skonfigurowany w aplikacji.
  const expected = PropertiesService.getScriptProperties().getProperty("API_TOKEN")
    || "hBsuU2uyQQ6WO3MbA30DtVLb2SJhuiblRqH77g1Ns9M";
  return String(token || "") === String(expected);
}

function europrisStatsSpreadsheet_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty("STATS_SPREADSHEET_ID");

  if (id) {
    try { return SpreadsheetApp.openById(id); } catch (err) {}
  }

  const file = SpreadsheetApp.create("Europris Dostawy - Statystyki");
  props.setProperty("STATS_SPREADSHEET_ID", file.getId());
  return file;
}

function europrisStatsSheet_() {
  const ss = europrisStatsSpreadsheet_();
  let sheet = ss.getSheetByName(EUROPRIS_STATS_SHEET);
  if (!sheet) {
    sheet = ss.insertSheet(EUROPRIS_STATS_SHEET);
    sheet.appendRow([
      "timestamp", "day", "anonymousDayId", "event", "os", "browser",
      "device", "displayMode", "screenClass", "language", "version", "online", "result"
    ]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function europrisSafeCategory_(value, maxLength) {
  return String(value || "")
    .replace(/[^\p{L}\p{N} ._+\-<]/gu, "")
    .slice(0, maxLength || 40) || "Other";
}

function europrisSaveStatsEvent_(body) {
  const event = String(body.event || "");
  if (!EUROPRIS_ALLOWED_EVENTS.has(event)) return;

  const day = /^\d{4}-\d{2}-\d{2}$/.test(String(body.day || ""))
    ? String(body.day)
    : Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd");

  const anonymousDayId = europrisSafeCategory_(body.anonymousDayId, 40);
  const os = EUROPRIS_ALLOWED_OS.has(body.os) ? body.os : "Other";
  const device = EUROPRIS_ALLOWED_DEVICE.has(body.device) ? body.device : "Desktop";
  const displayMode = EUROPRIS_ALLOWED_MODE.has(body.displayMode) ? body.displayMode : "Browser";
  const language = EUROPRIS_ALLOWED_LANG.has(body.language) ? body.language : "other";

  const sheet = europrisStatsSheet_();
  sheet.appendRow([
    new Date(),
    day,
    anonymousDayId,
    event,
    os,
    europrisSafeCategory_(body.browser, 30),
    device,
    displayMode,
    europrisSafeCategory_(body.screenClass, 20),
    language,
    europrisSafeCategory_(body.version, 20),
    body.online === false ? "false" : "true",
    europrisSafeCategory_(body.result, 40)
  ]);

  // Sprzątanie jest lekkie i uruchamia się mniej więcej raz na 50 zapisów.
  if (sheet.getLastRow() % 50 === 0) europrisDeleteOldStats_();
}

function europrisDeleteOldStats_() {
  const sheet = europrisStatsSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - EUROPRIS_STATS_RETENTION_DAYS);
  cutoff.setHours(0, 0, 0, 0);

  const dates = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  let deleteCount = 0;
  for (let i = 0; i < dates.length; i++) {
    const value = dates[i][0];
    if (value instanceof Date && value < cutoff) deleteCount++;
    else break;
  }
  if (deleteCount > 0) sheet.deleteRows(2, deleteCount);
}

function europrisStatsSummary_() {
  const sheet = europrisStatsSheet_();
  const lastRow = sheet.getLastRow();
  const now = new Date();
  const today = Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyy-MM-dd");

  const out = {
    ok: true,
    generatedAt: Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyy-MM-dd HH:mm:ss"),
    summary: { devicesToday: 0, opensToday: 0, devices7d: 0, devices30d: 0 },
    os: {}, browser: {}, device: {}, displayMode: {}, screenClass: {},
    language: {}, version: {}, events: {}
  };
  if (lastRow < 2) return out;

  const values = sheet.getRange(2, 1, lastRow - 1, 13).getValues();
  const day7 = new Date(now); day7.setDate(day7.getDate() - 6); day7.setHours(0,0,0,0);
  const day30 = new Date(now); day30.setDate(day30.getDate() - 29); day30.setHours(0,0,0,0);

  const devicesToday = new Set();
  const devices7d = new Set();
  const devices30d = new Set();

  function inc(obj, key) {
    key = String(key || "Other");
    obj[key] = (obj[key] || 0) + 1;
  }

  values.forEach(row => {
    const ts = row[0] instanceof Date ? row[0] : new Date(row[0]);
    if (isNaN(ts)) return;

    const day = String(row[1] || "");
    const anon = String(row[2] || "");
    const event = String(row[3] || "");
    const uniqueKey = `${day}|${anon}`;

    if (day === today) {
      devicesToday.add(uniqueKey);
      if (event === "app_open") out.summary.opensToday++;
    }
    if (ts >= day7) devices7d.add(uniqueKey);
    if (ts >= day30) {
      devices30d.add(uniqueKey);
      inc(out.events, event);
      inc(out.os, row[4]);
      inc(out.browser, row[5]);
      inc(out.device, row[6]);
      inc(out.displayMode, row[7]);
      inc(out.screenClass, row[8]);
      inc(out.language, row[9]);
      inc(out.version, row[10]);
    }
  });

  out.summary.devicesToday = devicesToday.size;
  out.summary.devices7d = devices7d.size;
  out.summary.devices30d = devices30d.size;
  return out;
}

function europrisJson_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}