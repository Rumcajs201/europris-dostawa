﻿param(
  [Parameter(Mandatory=$true)]
  [string]$V48Folder
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$packageRoot = Split-Path -Parent $root
$out = Join-Path $packageRoot "NOWA_WERSJA_DO_WGRANIA"
$backup = Join-Path $packageRoot "KOPIA_AWARYJNA_v48"

if (!(Test-Path $V48Folder)) { throw "Nie znaleziono folderu v48: $V48Folder" }
if (!(Test-Path (Join-Path $V48Folder "index.html"))) { throw "Folder v48 nie zawiera index.html" }

Remove-Item $out -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $backup -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item $V48Folder $backup -Recurse -Force
Copy-Item $V48Folder $out -Recurse -Force

Copy-Item (Join-Path $root "analytics.js") (Join-Path $out "analytics.js") -Force
Copy-Item (Join-Path $root "stats-panel.js") (Join-Path $out "stats-panel.js") -Force
Copy-Item (Join-Path $root "stats.css") (Join-Path $out "stats.css") -Force
Copy-Item (Join-Path $root "PRYWATNOSC_STATYSTYKI.txt") (Join-Path $out "PRYWATNOSC_STATYSTYKI.txt") -Force

$indexPath = Join-Path $out "index.html"
$html = Get-Content $indexPath -Raw -Encoding UTF8

if ($html -notmatch 'stats\.css') {
  $html = $html -replace '</head>', "  <link rel=`"stylesheet`" href=`"stats.css?v=49`">`r`n</head>"
}
if ($html -notmatch 'analytics\.js') {
  $html = $html -replace '</body>', @"
<script src="analytics.js?v=49"></script>
<script src="stats-panel.js?v=49"></script>
</body>
"@
}

# Tworzy bezpieczny kontener panelu. Integracja widoczności następuje przez funkcję admina.
if ($html -notmatch 'id="adminStatsPanel"') {
  $html = $html -replace '</main>', @"
<section id="adminStatsPanel" class="stats-panel" hidden></section>
</main>
"@
}

# Dodaje funkcję pomocniczą, którą należy wywołać po poprawnym PIN-ie administratora.
if ($html -notmatch 'showEuroprisAdminStats') {
  $html = $html -replace '<script src="analytics\.js\?v=49"></script>', @"
<script>
window.showEuroprisAdminStats = function () {
  const panel = document.getElementById("adminStatsPanel");
  if (!panel) return;
  panel.hidden = false;
  window.EuroprisStatsPanel?.load(panel);
};
window.hideEuroprisAdminStats = function () {
  const panel = document.getElementById("adminStatsPanel");
  if (panel) panel.hidden = true;
};
</script>
<script src="analytics.js?v=49"></script>
"@
}

Set-Content $indexPath $html -Encoding UTF8

Write-Host ""
Write-Host "GOTOWE:"
Write-Host "1. Kopia v48: $backup"
Write-Host "2. Nowa wersja: $out"
Write-Host ""
Write-Host "WAŻNE: w kodzie logowania administratora po zaakceptowaniu PIN 4878"
Write-Host "wywołaj: showEuroprisAdminStats();"
Write-Host "Przy wylogowaniu wywołaj: hideEuroprisAdminStats();"