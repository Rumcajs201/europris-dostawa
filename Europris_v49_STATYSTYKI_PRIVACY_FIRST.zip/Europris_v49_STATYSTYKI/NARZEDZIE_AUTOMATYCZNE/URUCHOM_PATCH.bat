﻿@echo off
chcp 65001 >nul
echo.
echo EUROPRIS v49 - AUTOMATYCZNE DODANIE STATYSTYK
echo.
set /p V48=Przeciagnij tutaj folder z pelna wersja v48 i nacisnij ENTER: 
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PATCH_v48_DO_v49.ps1" -V48Folder "%V48%"
echo.
pause