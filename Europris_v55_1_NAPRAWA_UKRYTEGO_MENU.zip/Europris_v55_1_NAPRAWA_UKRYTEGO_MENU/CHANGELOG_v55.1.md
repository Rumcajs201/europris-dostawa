# Europris Dostawy v55.1 — naprawa ukrytego menu

## Przyczyna
Odwołania do `analytics.js` i `stats-panel.js` zostały błędnie wstawione
do szablonu HTML raportu miesięcznego A4.

Skutek:
- na dole aplikacji wyświetlał się fragment kodu jako tekst,
- główny JavaScript kończył działanie zbyt wcześnie,
- przytrzymanie logo nie otwierało ukrytego panelu.

## Naprawa
- usunięto skrypty z szablonu raportu A4,
- umieszczono je przy prawdziwym końcu strony,
- zmieniono cache Service Workera,
- sprawdzono składnię głównego skryptu i plików zewnętrznych.

Nie zmieniono działania pozostałych funkcji.
