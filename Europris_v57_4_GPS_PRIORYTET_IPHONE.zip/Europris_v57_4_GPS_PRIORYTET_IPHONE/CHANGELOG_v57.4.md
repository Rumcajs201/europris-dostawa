# Europris Dostawy v57.4 — GPS iPhone

Porównano działającą wersję v50.4 z aktualną aplikacją.

Wynik:
- sama funkcja GPS była identyczna;
- różnicą było równoległe uruchamianie nowych modułów i aktywna aktualizacja
  Service Workera podczas startu aplikacji.

Wprowadzone zmiany:
- przywrócono cały blok HTML i JavaScript lokalizacji z v50.4;
- przywrócono automatyczne uruchomienie GPS z v50.4;
- usunięto dodatkowy przycisk „Włącz lokalizację”;
- pogoda, statystyki, analityka i lista kierowców uruchamiają się 2,5 sekundy później;
- Service Worker nie przeładowuje aplikacji podczas startu;
- zachowano wszystkie nowsze funkcje aplikacji.
