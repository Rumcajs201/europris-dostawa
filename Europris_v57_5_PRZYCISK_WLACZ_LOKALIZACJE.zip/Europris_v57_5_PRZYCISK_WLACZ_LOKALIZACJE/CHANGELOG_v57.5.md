# Europris Dostawy v57.5

- Przywrócono przycisk „Włącz lokalizację”.
- Przycisk znajduje się obok „Sprawdź ponownie”.
- Kliknięcie uruchamia dokładny GPS bezpośrednio z gestu użytkownika.
- Automatyczne wyszukiwanie najbliższego sklepu przy starcie pozostaje aktywne.
- Pozostałe funkcje aplikacji pozostają bez zmian.
